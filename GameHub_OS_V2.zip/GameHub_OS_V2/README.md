# GameHub OS 2.0

## Update your existing GitHub Pages site
1. Download and extract this ZIP.
2. Open your `gamehub-os` repository on GitHub.
3. Choose **Add file → Upload files**.
4. Upload the contents of this folder, including the `icons` folder. Do not upload the outer `GameHub_OS_V2` folder itself.
5. Choose **Commit changes**.
6. Wait for GitHub Pages to redeploy, then refresh your site. If an old version remains, hard-refresh with Ctrl+Shift+R.

## Features
- Searchable game library with categories
- Favorites and recently opened games (saved on this device)
- Four color themes
- Browser Gaming Mode
- Manual fullscreen
- Roblox official website shortcut
- PWA manifest, icon and service worker

Some external games may be blocked by school filters or require their official app/player. This dashboard cannot bypass school restrictions.
