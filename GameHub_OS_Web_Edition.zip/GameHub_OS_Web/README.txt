GAMEHUB OS WEB EDITION

This package is a browser dashboard, not a Chrome extension and not a ChromeOS replacement.

QUICK TEST (no Developer mode):
1. Download and extract GameHub_OS_Web_Edition.zip.
2. Open the extracted folder in the Chromebook Files app.
3. Double-click index.html and choose Chrome if asked.
4. Use the Roblox and game links. The fullscreen button must be clicked by the user.

IMPORTANT INSTALLATION LIMIT:
A proper installable PWA needs to be served from an HTTPS website (or localhost). A local HTML file can be used as a dashboard, but its service worker cannot be installed from file://.
To get the app-style install option, the files must be hosted on an HTTPS site that your school allows. Then open that site in Chrome and use the install icon in the address bar, or Chrome menu > Cast, save and share > Install page as app (wording can vary). Your school administrator may disable installation.

ROBLOX:
The Roblox button opens the official Roblox website. Some Roblox experiences require the official Roblox app/player, which a managed Chromebook may not permit.

SCHOOL DEVICE:
Do not change device Developer mode or try to bypass school management. Ask school IT if hosting sites or app installation are blocked.
